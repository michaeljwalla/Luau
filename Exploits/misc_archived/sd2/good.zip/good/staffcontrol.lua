if game.CoreGui:FindFirstChild("staffcontrol") then game.CoreGui.staffcontrol:Destroy() end
if _G.controlrunning and _G.controlrunning.Connected then _G.controlrunning:Disconnect() end
if _G.stafftracers then for i,v in pairs(_G.stafftracers) do v.Tracer:Destroy() v.Billboard:Destroy() end end
if _G.stafftraceloop then _G.stafftraceloop:Disconnect() end
if _G.trackmouse then _G.trackmouse = false end
--sethiddenproperty(game.Players.LocalPlayer,"MaxSimulationRadius", math.huge)
_G.mouse = game.Players.LocalPlayer:GetMouse()
_G.stafftracers = {}

local colorstart = BrickColor.new("Deep blue").Color
local colorend = BrickColor.new("Alder").Color
local difr,difg,difb = colorend.R-colorstart.R, colorend.G-colorstart.G, colorend.B-colorstart.B
print(difr,difg,difb)
local loadtracers = false

local lp = game.Players.LocalPlayer
local mae = 5 --margin of error
local lmae = 5 --lightning staff

local off = true
local types = {"None","Manual", "Auto"}
local healtype = types[1]
local lighttype = types[1]
local rockettypes = {"None", "Manual", "Homing", "FORTNITE"}
local rockettype = rockettypes[1]

function default(item)
	item.BackgroundColor3 = Color3.new(0.333333, 0.333333, 0.333333)
	item.Size = UDim2.new(0, 150, 0, 25)
	item.Font = Enum.Font.SourceSans
	item.TextColor3 = Color3.new(1, 1, 1)
	item.TextScaled = true
	item.TextSize = 14
	item.TextWrapped = true
	return item
end

local defaultbg = Color3.new(1/3,1/3,1/3) --lazy
local ui = Instance.new("ScreenGui", game.CoreGui)
ui.Name = "staffcontrol"
local main = Instance.new("Frame", ui)
main.Name = "Heal Gui"
main.Size = UDim2.new(1,0,1,0)
main.BackgroundTransparency = 1
local heallabel = Instance.new("Frame", main)
heallabel.Name = "color frame"
heallabel.Position = UDim2.new(0,0,0.3,-30)
heallabel.Size = UDim2.new(0,150,0,5)
heallabel.BackgroundColor3 = BrickColor.new("Gold").Color
local healbtn = default(Instance.new("TextButton", main))
healbtn.Position = UDim2.new(0,0,0.3,0)
healbtn.Name = "HealOptions"
healbtn.Text = string.format("Heal Type: %s", healtype)

local curpl = game.Players.LocalPlayer.Name
local plrbox = default(Instance.new("TextBox", main))
plrbox.Name = "PlayerSelect"
plrbox.Position = UDim2.new(-1,0,0.3,25)
plrbox.Text = game.Players.LocalPlayer.Name
plrbox.TextColor3 = Color3.new(0.7,0.7,0.7)

plrbox.FocusLost:Connect(function()
	local txt = string.lower(plrbox.Text)
	for i,v in next, game.Players:GetPlayers() do
		local start = string.lower(v.Name):find(txt)
		if start == 1 then
			curpl = v.Name
		end
		plrbox.Text = curpl
	end
end)
local index = 1
healbtn.MouseButton1Down:Connect(function()
	index += 1
	if index > #types then index = 1 end
	healtype = types[index]
	healbtn.Text = string.format("Heal Type: %s", types[index])
	if healtype == "Player" then plrbox.Position = UDim2.new(0,0,0.3,25) else do plrbox.Position = UDim2.new(-1,0,0.3,25) end end
end)
local marginoferror = plrbox:Clone()
marginoferror.Parent = main
marginoferror.Position = UDim2.new(0,0,0.3,-25)
marginoferror.Name = "Spread"
marginoferror.Text = string.format("Spread: %d", mae)
marginoferror.FocusLost:Connect(function()
	if tonumber(marginoferror.Text) then mae = math.floor(marginoferror.Text) end
	marginoferror.Text = string.format("Spread: %d", mae)
end)

local lightframe = main:Clone()
lightframe.Name = "Lightning Gui"
lightframe.Parent = ui
lightframe["color frame"].BackgroundColor3 = BrickColor.new("Alder").Color
lightframe.Position += UDim2.new(0,0,0.4,0)
lightframe.HealOptions.Text = string.format("Light Type: %s", lighttype)

local lindex = 1
lightframe.HealOptions.MouseButton1Down:Connect(function()
	lindex += 1
	if lindex > #types then lindex = 1 end
	lighttype = types[lindex]
	lightframe.HealOptions.Text = string.format("Light Type: %s", lighttype)
end)
lightframe.Spread.FocusLost:Connect(function()
	if tonumber(lightframe.Spread.Text) then lmae = math.floor(lightframe.Spread.Text) end
	lightframe.Spread.Text = string.format("Spread: %d", lmae)
end)
local rocketfocus = Instance.new("Part", game.Workspace)
rocketfocus.Size = Vector3.new(0,0,0)
rocketfocus.Anchored = true
rocketfocus.Name = "RocketFocus"
rocketfocus.CanCollide = false
wait(0.1)
_G.trackmouse = true
spawn(function()
	while task.wait() and _G.trackmouse do
		rocketfocus.CFrame = _G.mouse.Hit + Vector3.new(0,5,0)
	end
	rocketfocus:Destroy()
end)

local rocketframe = lightframe:Clone()
rocketframe.Name = "Rocket Gui"
rocketframe.Parent = ui
rocketframe["color frame"].BackgroundColor3 = BrickColor.new("Smokey grey").Color
rocketframe.Position += UDim2.new(0,0,0,75)
rocketframe.HealOptions.Text = string.format("Rocket Type: %s", rockettype)

local rspeed = 100
rocketframe.Spread.Text =  string.format("Speed: %d", rspeed)
rocketframe.Spread.FocusLost:Connect(function()
	if tonumber(rocketframe.Spread.Text) and tonumber(rocketframe.Spread.Text) >= 70 then rspeed = math.floor(rocketframe.Spread.Text) end
	rocketframe.Spread.Text = string.format("Speed: %d", rspeed)
end)
local rindex = 1
rocketframe.HealOptions.MouseButton1Down:Connect(function()
	rindex += 1
	if rindex > #rockettypes then rindex = 1 end
	rockettype = rockettypes[rindex]
	rocketframe.HealOptions.Text = string.format("Rocket Type: %s", rockettype)
	if rockettype == "Homing" then rocketframe.PlayerSelect.Position = UDim2.new(0,0,0.3,25) else do rocketframe.PlayerSelect.Position = UDim2.new(-1,0,0.3,25) end end
end)
local rplr = game.Players.LocalPlayer.Name
rocketframe.PlayerSelect.FocusLost:Connect(function()
	local txt = string.lower(rocketframe.PlayerSelect.Text)
	for i,v in next, game.Players:GetPlayers() do
		local start = string.lower(v.Name):find(txt)
		if start == 1 then
			rplr = v.Name break
		end
	end
	rocketframe.PlayerSelect.Text = rplr
end)
function comma(amount)
  local formatted = amount
  while true do  
    formatted, k = string.gsub(formatted, "^(-?%d+)(%d%d%d)", '%1,%2')
    if (k==0) then
      break
    end
  end
  return formatted
end
function findfirstalive(self: Instance)
	if not self or not typeof(self) == "Instance" then self = game.Workspace.Disaster end
	local pap = {}
	for i,v in pairs(self:GetDescendants()) do
		if game.Workspace.Effects:FindFirstChild("SpellCircle") then return false end --karma shield 😟
		if v:IsA("Humanoid") and v.Health > 0 then
			table.insert(pap, v.Parent:FindFirstChildWhichIsA("BasePart"))
		end
	end
	if #pap < 1 then return false end
	local leastmag = {Parent = nil, Mag = math.huge}
	for i,v in pairs(pap) do
		local mag = (lp.Character.HumanoidRootPart.Position - v.Position).Magnitude
		if mag < leastmag.Mag then
			leastmag = {Parent = v.Parent, Mag = mag}
		end
	end
	return leastmag.Parent
end

local espgui = Instance.new("BillboardGui")
local esp = Instance.new("TextLabel",espgui)
espgui.Name = "ESP";
espgui.ResetOnSpawn = true
espgui.AlwaysOnTop = true;
espgui.LightInfluence = 0;
espgui.Size = UDim2.new(1.75, 0, 1.75, 0);
espgui.ZIndexBehavior = Enum.ZIndexBehavior.Global
esp.BackgroundColor3 = Color3.fromRGB(255, 255, 255);
esp.Text = ""
esp.Size = UDim2.new(0.0001, 0.00001, 0.0001, 0.00001);
esp.BorderSizePixel = 4;
esp.BorderColor3 = Color3.new(1,1,1)
esp.BorderSizePixel = 0
esp.Font = "GothamSemibold"
esp.TextSize = 18
esp.TextColor3 = colorstart

            
local tracerbase = Instance.new("Part")
tracerbase.CFrame = game.Workspace[game.Players.LocalPlayer.Name].HumanoidRootPart.CFrame
tracerbase.Anchored = true
tracerbase.CanCollide = false
tracerbase.Transparency = 0.5
tracerbase.Orientation = Vector3.new(0,0,0)
tracerbase.Material = "Neon"
tracerbase.Size = Vector3.new(0.2,.2,0)
tracerbase.Name = "Tracer"
tracerbase.Color = colorstart
function newtracer(lookAt, text)
	if typeof(lookAt) ~= "Instance" then return false end
	local tracer = tracerbase:Clone()
	tracer.Parent = lookAt
	local billboard = espgui:Clone()
	billboard.Parent = lookAt
	billboard.TextLabel.Text = text
	table.insert(_G.stafftracers, {Tracer = tracer, Tracking = lookAt, Billboard = billboard, Humanoid = lookAt.Parent:FindFirstChildWhichIsA("Humanoid") or nil})
end
function updatetracers()
	if not lp.Character and lp.Character.HumanoidRootPart then return end
	local tremoved = 0
	for i,v in pairs(_G.stafftracers) do
		local tracer, lookAt, billboard, humanoid = v.Tracer, v.Tracking, v.Billboard, v.Humanoid
	    if (not (tracer.Parent or lookAt.Parent)) or (not humanoid or humanoid.Health < 1) then tracer:Destroy() billboard:Destroy() table.remove(_G.stafftracers, i-tremoved) tremoved += 1 end
	    if tracer.Parent or lookAt.Parent then
		    lookAt = lookAt.Position
		    pcall(function()
		    	local h = humanoid
			    pos = lp.Character.HumanoidRootPart.Position
			    tracer.Size = Vector3.new(tracer.Size["X"], tracer.Size["Y"], (pos - lookAt).Magnitude)
			    avg = Vector3.new((pos["X"]+lookAt["X"]) / 2,(pos["Y"]+lookAt["Y"]) / 2,(pos["Z"]+lookAt["Z"]) / 2)
			    tracer.CFrame = CFrame.new(avg, lookAt)
			    billboard.TextLabel.Text = string.format("%s/%s (%s%%)", comma(humanoid.Health),comma(humanoid.MaxHealth), tostring(100*humanoid.Health/humanoid.MaxHealth):sub(1,4))
		    	billboard.TextLabel.TextColor3 =  Color3.new(colorstart.R+difr*(1-difr*(h.Health/h.MaxHealth)),colorstart.G+difg*(1-difg*(h.Health/h.MaxHealth)),colorstart.B+difb*(1-difb*(h.Health/h.MaxHealth)))
		    	tracer.Color =  Color3.new(colorstart.R+difr*(1-difr*(h.Health/h.MaxHealth)),colorstart.G+difg*(1-difg*(h.Health/h.MaxHealth)),colorstart.B+difb*(1-difb*(h.Health/h.MaxHealth)))
		    end)
		end
    end
end
local targeting
function rmain(v)
	local lightning, rocket
    if v.Name:find("Rocket") then
        local t = tick()
    	while tick()-t < 5 and not v:FindFirstChildWhichIsA("RocketPropulsion") and not v:FindFirstChild("creator") do wait() end
    	if not v:FindFirstChild'creator' then return end
    	if tostring(v.creator.Value) == game.Players.LocalPlayer.Name then rocket = v end
    	if rocket then
    		if rockettype == "Manual" or rockettype == "FORTNITE" then
    			v.RocketPropulsion.MaxSpeed = rspeed 
    			v.RocketPropulsion.TargetOffset = Vector3.new(0,-5.5,0) 
    			v.RocketPropulsion.Target = rocketfocus
    		end
    		if rockettype == "FORTNITE" then
    			task.spawn(function() 
    				while v.Transparency == 0 and v.Parent and game.Players.LocalPlayer.Character and game.Players.LocalPlayer.Character:FindFirstChild("Humanoid") and not game.Players.LocalPlayer.Character.Humanoid.Jump do
    					task.wait()
    					game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(v.Position)*CFrame.Angles(0,math.rad(v.Orientation.Y),0) + Vector3.new(0,3,0)
    					game.Players.LocalPlayer.Character.HumanoidRootPart.Velocity = v.Velocity--Vector3.new(game.Players.LocalPlayer.Character.HumanoidRootPart.Velocity.X,0,game.Players.LocalPlayer.Character.HumanoidRootPart.Velocity.Z)
    				end
    				game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(game.Players.LocalPlayer.Character.HumanoidRootPart.Position)
    			end)
    		end
    		if rockettype == "Homing" and game.Players[rplr].Character then
    			v.RocketPropulsion.MaxSpeed = rspeed 
    			v.RocketPropulsion.TargetOffset = Vector3.new(0,1,0) 
    			v.RocketPropulsion.Target = game.Players[rplr].Character.HumanoidRootPart
    		end
    	end
    	return;
    elseif v.Name == "Projectile" then
        local t = tick()
		while tick() - t < 5 and not v:FindFirstChild("Creator") and not v:FindFirstChild("Mesh") do wait() end
		if not v:FindFirstChild'Creator' or not v:FindFirstChild'Mesh' then return end
		if ((tostring(v.Creator.Value) == game.Players.LocalPlayer.name) or (tostring(v.Creator.Value) == "YerminatorStonks2")) and v.Mesh.MeshType == Enum.MeshType.Sphere then
			if v.BrickColor == BrickColor.new("Pink") then 
				lightning = v 
				--spawn(function() local t = tick() while (not v:FindFirstChild("ReadyParticle")) and tick()-t < 2 do wait() end if v:FindFirstChild("ReadyParticle") then v.ReadyParticle.Color = ColorSequence.new(1,1,1) end end)
			end
		end
	end
    
	--separated bc easier to look at
	while wait() and v:IsDescendantOf(game) and lightning do
		 if lightning then
		 	if v:FindFirstChildWhichIsA("ParticleEmitter") then v:FindFirstChildWhichIsA("ParticleEmitter"):Destroy() end
			if lighttype == "Manual" then
				v.CFrame = _G.mouse.Hit + Vector3.new(math.random(-lmae,lmae),math.random(-lmae,lmae),math.random(-lmae,lmae))
				else if lighttype == "Auto" then
					local ffa = findfirstalive()
					if ffa then
						local h = ffa:FindFirstChildWhichIsA("Humanoid")
						--rather have torso first bc its more centered (more hit chance)
						local b = ffa:FindFirstChild("Torso") or ffa:FindFirstChild("Head") or ffa:FindFirstChildWhichIsA("BasePart")
						if (not game.Workspace.Effects:FindFirstChild("Spell Circle")) and b then
					        targeting = b
					        local remmed = 0
					        if loadtracers then 
					        	local traced
						        for e,c in pairs(_G.stafftracers) do
									if targeting ~= c.Tracking then
										c.Tracer:Destroy()
										c.Billboard:Destroy()
										table.remove(_G.stafftracers, e - remmed)
										remmed += 1
									else do
										traced = true
									end
									end
								end
								v.Color = Color3.new(colorstart.R+difr*(1-difr*(h.Health/h.MaxHealth)),colorstart.G+difg*(1-difg*(h.Health/h.MaxHealth)),colorstart.B+difb*(1-difb*(h.Health/h.MaxHealth)))
								if not traced then newtracer(b, string.format("%s/%s (%s%%)", comma(h.Health),comma(h.MaxHealth), tostring(100*h.Health/h.MaxHealth):sub(1,4))) end
							end
							v.CFrame = b.CFrame + Vector3.new(math.random(-lmae,lmae),math.random(-lmae,lmae),math.random(-lmae,lmae))
						end
					end
				end
			end
		end
	end
	return
end
--if v.Parent is nil then rerun (put into function)
main.Visible = false
_G.controlrunning = game.Workspace.ChildAdded:Connect(function(v)
	rmain(v)
end)
if loadtracers then _G.stafftraceloop = game.RunService.RenderStepped:Connect(function()
		updatetracers()
	end)
end
