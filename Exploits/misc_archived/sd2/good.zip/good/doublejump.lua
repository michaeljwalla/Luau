local lp = game.Players.LocalPlayer
if _G.djump then _G.djump:Disconnect() end
_G.djump = game:GetService("UserInputService").InputBegan:Connect(function(what, isFocused)
    if not (not isFocused and what.KeyCode == Enum.KeyCode.R) then return end
    local last = lp.Character:FindFirstChildWhichIsA("Tool")
    local trowel = lp.Character:FindFirstChild("Trowel") or lp.Backpack:FindFirstChild("Trowel")
    
    if last.Parent then last.Parent = lp.Backpack end
    if trowel.Parent then trowel.Parent = lp.Character end
    game:GetService("Players").LocalPlayer.Character.Trowel.FireWeapon:FireServer(lp.Character.HumanoidRootPart.Position + lp.Character.HumanoidRootPart.CFrame.LookVector*4*(1+3*lp:GetNetworkPing())-Vector3.new(0,2,0))
    task.wait(0.1)
    if trowel.Parent then trowel.Parent = lp.Backpack end
    if last.Parent then last.Parent = lp.Character end
end)