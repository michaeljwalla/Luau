if _G.pinkballs then for i,v in pairs(_G.pinkballs) do v:Disconnect() end end

old = hookmetamethod(game, '__index', newcclosure(function(self, index)
    if checkcaller() then
        if index == 'once' then
            return function(whatconnection, func)
                return coroutine.wrap(function() return func(self[whatconnection]:Wait()) end)()
            end
        end
        return old(self, index)
    end
    return old(self, index)
end))

_G.pinkballs = {}
local activeorbs = setmetatable({}, {
    __index = function(self, index)
        if index == 'destroy' then
            return function(what)
                local t = table.find(self, what)
                if not t then return end
                table.remove(self, t)
                return t
            end
        end
    end
})

local lp = game.Players.LocalPlayer
local lpc = lp.Character
table.insert(_G.pinkballs, lp.CharacterAdded:Connect(function(char) lpc = char end))
function findfirstalive(self: Instance)
	if not self or not typeof(self) == "Instance" then self = game.Workspace.Disaster end
	local pap = {}
	for i,v in pairs(self:GetDescendants()) do
		--if game.Workspace.Effects:FindFirstChild("SpellCircle") then return false end --karma shield 😟
		if v:IsA("Humanoid") and v.Health > 0 then
			table.insert(pap, v.Parent:FindFirstChild("Head") or v.Parent:FindFirstChild("Torso") or FindFirstChildWhichIsA("BasePart"))
		end
	end
	if #pap < 1 then return false end
	local leastmag = {Parent = nil, Mag = math.huge}
	for i,v in pairs(pap) do
		local mag = (lp.Character.HumanoidRootPart.Position - v.Position).Magnitude
		if mag < leastmag.Mag then
			leastmag = {Parent = v.Parent, Mag = mag}
		end
	end
	return leastmag.Parent
end
adder = game.Workspace.ChildAdded:Connect(function(v)
    if not lpc then return end
    if v.Name == 'Handle' and (v:WaitForChild("ThrowSound", 1) and v.ThrowSound.SoundId == 'http://www.roblox.com/asset/?id=28166510') and v:IsA("BasePart") then
        
        local hrp = lpc:FindFirstChild("HumanoidRootPart")
        if not hrp then return end
        local t = tick()
        repeat wait() until isnetworkowner(v) or tick()-t > 3
        if isnetworkowner(v) then
            table.insert(activeorbs, v)
            local bv = v:WaitForChild("BodyVelocity")
            bv:Destroy()
            v.Position = lpc.HumanoidRootPart.Position
            v.once("AncestryChanged", function() activeorbs.destroy(v) end)
        end
        
    end
end)
table.insert(_G.pinkballs, adder)

local rotate = 0
loop = game.RunService.Heartbeat:Connect(function()
    local remtable = {}
    for i,v in pairs(activeorbs) do
        if not isnetworkowner(v) or v.Anchored or not v:IsDescendantOf(game) then activeorbs.destroy(v) end
    end
    local ffa = findfirstalive()
    if ffa then
        ffa = ffa:FindFirstChild("Torso") or ffa:FindFirstChildWhichIsA("BasePart")
        for i,v in pairs(activeorbs) do
            firetouchinterest(v, ffa, 0)
            firetouchinterest(v, ffa, 1)
        end
    end
    local multiplier = 0*math.clamp(#activeorbs,2,5)
    for i,v in pairs(activeorbs) do
        local pos = v:FindFirstChild("BodyPosition")
        if not pos then pos = Instance.new("BodyPosition", v) pos.D /= 3 end
        pos.Position = lpc.HumanoidRootPart.Position + Vector3.new(multiplier*math.sin(math.rad((i/#activeorbs)*360+ rotate)), 2*math.sin(math.rad(rotate)), multiplier*math.cos(math.rad((i/#activeorbs)*360 + rotate)))
        
    end
    rotate = rotate < 360 and rotate + 1 or 0
end)
table.insert(_G.pinkballs, loop)