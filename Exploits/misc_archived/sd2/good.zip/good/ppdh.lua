if _G.ppdh then _G.ppdh:Disconnect() end
local lp = game.Players.LocalPlayer
local char = function(chr)
    chr.ChildAdded:Connect(function(c)
        if c.Name == 'Darkheart' then
            c:FindFirstChild("AnimationScript").Disabled = true
            local part = c:FindFirstChild("Handle")
            if not part then return end
            if part:FindFirstChild("Mesh") then part.Mesh:Destroy() end
            if swordthing then swordthing:Disconnect() end
            c.GripForward = Vector3.new(0,0,1)
            c.GripPos = Vector3.new(1.5,1.5,-0.95)
            c.GripRight = Vector3.new(0,1,0)
            c.GripUp = Vector3.new(1,0,0)
            local debounce = false
            swordthing = c.Changed:Connect(function(v)
                if debounce then return end
                if not (c.GripForward == Vector3.new(0,0,1)
                and c.GripPos == Vector3.new(1.5,1.5,-0.95)
                and c.GripRight == Vector3.new(0,1,0)
                and c.GripUp == Vector3.new(1,0,0)) then
                    debounce = true
                    c.GripForward = Vector3.new(0,0,1)
                    c.GripPos = Vector3.new(1.5,1.5,-0.95)
                    c.GripRight = Vector3.new(0,1,0)
                    c.GripUp = Vector3.new(1,0,0)
                    debounce = false
            end
            end)
        elseif c.Name == 'Healing Staff' then
            local part = c:FindFirstChild("LocalScript") and c:FindFirstChild("Handle")
            if not part then return end
            getsenv(c.LocalScript).SetAnimation = function() return end
            if part:FindFirstChild("Mesh") then part.Mesh:Destroy() end
            if hstaffthing then hstaffthing:Disconnect() end
            local debounce = false
            hstaffthing = c.Changed:Connect(function(v)
                if debounce then return end
                if not (c.GripForward == Vector3.new(0,1,0)
                and c.GripPos == Vector3.new(-1.5,-1.5,-1.5)
                and c.GripRight == Vector3.new(-1,0,0)
                and c.GripUp == Vector3.new(0,0,-1)) then
                    debounce = true
                    c.GripForward = Vector3.new(0,1,0)
                    c.GripPos = Vector3.new(-1.5,-1.5,-1.5)
                    c.GripRight = Vector3.new(-1,0,0)
                    c.GripUp = Vector3.new(0,0,-1)
                    debounce = false
            end
            end)
            
        elseif c.Name == 'Rocket Launcher' then
            local part = c:FindFirstChild("Animation") and c:FindFirstChild("Handle")
            if not part then return end
            if part:FindFirstChild("Mesh") then part.Mesh:Destroy() end
            c.Animation.Disabled = true
            c.GripPos = Vector3.new(1.5,1.5,0.5)
            
            if rlthing then rlthing:Disconnect() end
            local debounce
            rlthing = c.Changed:Connect(function()
                if debounce then return end
                if not c.GripPos == Vector3.new(1.5,1.5,0.5) then debounce = true c.GripPos = Vector3.new(1.5,1.5,0.5) debounce = false end
            end)
        end
    end)
end

_G.ppdh = lp.CharacterAdded:Connect(char)
if lp.Character then char(lp.Character) end