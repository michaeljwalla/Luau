if not game.CoreGui:FindFirstChild("Remotes") then
    local new = Instance.new("ScreenGui", game.CoreGui)
    new.Name = "Remotes"
    local remotePress = Instance.new("TextButton", game.CoreGui.Remotes)
    remotePress.Name = "touchAll"
    remotePress.BackgroundColor3 = Color3.new(0.333333, 0.333333, 0.333333)
    remotePress.Size = UDim2.new(0, 150, 0, 25)
    remotePress.Font = Enum.Font.SourceSans
    remotePress.Text = "FireTouchInterest"
    remotePress.TextColor3 = Color3.new(1, 1, 1)
    remotePress.TextScaled = true
    remotePress.TextSize = 14
    remotePress.TextWrapped = true
    remotePress.Position = UDim2.new(0, 0, 0.95, -25)
    
    local chooseplayer = Instance.new("TextBox", new)
    chooseplayer.Name = "choose"
    chooseplayer.BackgroundColor3 = Color3.new(0.333333, 0.333333, 0.333333)
    chooseplayer.Size = UDim2.new(0, 150, 0, 25)
    chooseplayer.Font = Enum.Font.SourceSans
    chooseplayer.Text = game.Players.LocalPlayer.Name
    chooseplayer.TextColor3 = Color3.new(1, 1, 1)
    chooseplayer.TextScaled = true
    chooseplayer.TextSize = 14
    chooseplayer.TextWrapped = true
    chooseplayer.Position = UDim2.new(0, 0, 0.95, -50)
    remotePress.MouseButton1Down:Connect(function()
        if not game.Players:FindFirstChild(chooseplayer.Text) then return end
        local ctr = 0
        for i,v in pairs(game.Workspace:GetDescendants()) do
            if v.Name == "TouchInterest" and string.lower(v:GetFullName()):find("spawn") == nil then
                ctr += 1
                firetouchinterest(game.Workspace[chooseplayer.Text].HumanoidRootPart, v.Parent, 0)
                firetouchinterest(game.Workspace[chooseplayer.Text].HumanoidRootPart, v.Parent, 1)
            end
        end
        remotePress.Text = "Fired "..ctr
    end)
    local lastsent = game.Players.LocalPlayer.Name
    chooseplayer.FocusLost:Connect(function()
        local txt = string.lower(chooseplayer.Text)
        if txt:gsub("%s", "") == "" then
            chooseplayer.Text = game.Players.LocalPlayer.Name
        end
        for i,v in pairs(game.Players:GetPlayers()) do
            if string.lower(v.Name):find(txt) == 1 then
                chooseplayer.Text = v.Name
                lastsent = v.Name
                return
            end
        end
        chooseplayer.Text = lastsent
    end)
    game:GetService("UserInputService").InputBegan:Connect(function(key,chat) if key.KeyCode == Enum.KeyCode.Minus and not chat then remotePress.Visible = not remotePress.Visible chooseplayer.Visible = remotePress.Visible end end)
else do
    game.CoreGui.Remotes:Destroy()
end
end
