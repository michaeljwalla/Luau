if _G.ptbtrack then _G.ptbtrack:Disconnect() end
wait(1)
local c1, c2, c3
_G.ptbtrack = game.Workspace.Disaster.ChildAdded:Connect(function(dis)
    if dis.Name == "Press The Button" and dis:IsA("Model") then
        print("Found disaster")
        c1 = dis.DescendantAdded:Connect(function(part)
            if part.Name == "Trigger" and part:IsA("MeshPart") then
                print("Found trigger")
                c3 = part.Touched:Connect(function(touchedpart)
                    if game.Players:FindFirstChild(touchedpart.Parent.Name) then
                        print(touchedpart.Parent.Name.." pressed the button.")
                        c3:Disconnect()
                    end
                end)
            end
            end)
        c2 = dis.AncestryChanged:Connect(function() if not dis.Parent then c1:Disconnect() c2:Disconnect() end if c3 then c3:Disconnect() end end)
    end
end)
print("Tracking press")
local localconnection = _G.ptbtrack
while localconnection.Connected do wait() end
if c1 then c1:Disconnect() end if c2 then c2:Disconnect() end if c3 then c3:Disconnect() end
