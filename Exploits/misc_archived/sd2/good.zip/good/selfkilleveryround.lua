if _G.killself then _G.killself:Disconnect() end
local lp = game.Players.LocalPlayer
local function gethumanoid()
    return lp.Character and lp.Character:FindFirstChild("Humanoid")
end
local timer = game.ReplicatedStorage.Info.Timer
local dis = game.Workspace.Disaster
_G.killself = timer.Changed:Connect(function()
    if (timer.Value == 1) and gethumanoid() and #dis:GetChildren() > 0 then gethumanoid().Health = 0 end
end)