if _G.autopizza then _G.autopizza = false else do _G.autopizza = true end end
print(_G.autopizza)
local lp = game.Players.LocalPlayer
while _G.autopizza and wait() do
	if lp.Character and lp.Character:FindFirstChild("Pizza") then
		lp.Character:FindFirstChild("Pizza"):Activate()
	end
 end