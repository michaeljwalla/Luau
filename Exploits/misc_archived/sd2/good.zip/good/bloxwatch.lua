if _G.xpwatch then _G.xpwatch.stopall() end
local rs = game.ReplicatedStorage
local ds = rs.Board
local matchtbl = {
    streak = 'Streak',
    sblox = 'TotalEnemyCoins',
    hblox = 'TotalEnemyCoins2',
    ssurvs = 'TotalSurvivals',
    hsurvs = 'TotalSurvivals2'
}
local connections, players = {}, {}
local defcol = Color3.new(1/3,1/3,1/3)
local white = Color3.new(1,1,1)
local function plricon(uid)
    return game.Players:GetUserThumbnailAsync(uid, Enum.ThumbnailType.HeadShot, Enum.ThumbnailSize.Size48x48)
end
local function isnan(num)
    local inf = math.huge
    return (num ~= inf) and not (num < inf)
end
local function cv(amount)
      local formatted = amount
      while true do  
        formatted, k = string.gsub(formatted, "^(-?%d+)(%d%d%d)", '%1,%2')
        if (k==0) then
          break
        end
      end
      return formatted
    end
local function inssort(array)
    local len = #array
    for x = 2, len do
        local key = array[x].streak.Value
        local clone = array[x]
        local i = x - 1
        
        while i > 0 and array[i].streak.Value > key do
            array[i + 1] = array[i]
            i = i - 1
        end
        array[i + 1] = clone
    end
    
    --reverse
    for i = 0, math.round(len/2) do
        array[i+1], array[len-i] = array[len-i], array[i+1]
    end
    return array
end

_G.xpwatch = newproxy(true)
local main = Instance.new("ScreenGui", game.CoreGui)
main.Name = 'BloxWatch'

--setup

getmetatable(_G.xpwatch).__index = function(self, index)
    if index == 'stopall' then 
        return function() 
            for i,v in pairs(connections) do v:Disconnect() end
            players = nil
            connections = nil
            if main.Parent then main:Destroy() end
        end
    end
end
--end setup
local back = Instance.new("TextButton", main)
back.Size = UDim2.new(0,200,0,300)
back.Position = UDim2.new(0,200,1,-20)
local mm = Instance.new("Frame", back)
mm.Size = UDim2.fromScale(1,1)
mm.BackgroundColor3 = defcol
local title = Instance.new("TextLabel", mm)
title.Size = UDim2.new(1,0,0,20)
title.BackgroundColor3 = defcol
title.TextColor3 = white
title.RichText = true
title.Text = '<font color="#9999FF"><b>blox watch</b></font>'

local info = Instance.new("TextLabel", mm)
info.Size = UDim2.new(1,0,0,80)
info.Position = UDim2.fromOffset(0,-80)
info.BackgroundColor3 = defcol
info.TextColor3 = white
info.RichText = true
info.TextWrapped = true
info.Visible = false
local finfo = '<font color="#FFFFCC"><b>%s (%s)</b></font>\n\n<font color="#CCFFCC">Standard: %s <b><font color="#FFCC99">( %s:1 )</font></b></font>\n<font color="#FFCCCC">Hardcore: %s <b><font color="#FFCC99">( %s:1 )</font></b></font>'
local fname = '<font color="#FFFFCC">%s</font>'
local fblox = '<font color="#FFCC99">%s</font>'
info.Text = finfo:format(game.Players.LocalPlayer.DisplayName, game.Players.LocalPlayer.Name, 0, 0, 0, 0)
local scroller = Instance.new("Frame", mm)
scroller.Size = UDim2.new(1,0,1,-20)
scroller.Position = UDim2.new(0,0,0,20)
scroller.BackgroundColor3 = defcol
Instance.new("UIListLayout", scroller).SortOrder = Enum.SortOrder.LayoutOrder
local lastinfized
local function infize(plr) --info-ize
    lastinfized = plr
    local math1, math2 = plr.sblox.Value*2/plr.ssurvs.Value*100, plr.hblox.Value*2/plr.hsurvs.Value*100
    return plr.plr.Value.DisplayName,
        plr.plr.Value.Name,
        cv(plr.sblox.Value*2),
        cv(math.floor(isnan(math1) and 0 or math1)/100),
        cv(plr.hblox.Value*2),
        cv(math.floor(isnan(math2) and 0 or math2)/100)
end
local function update()
    inssort(players)
    for i,v in pairs(players) do
        if v.plr.Value == game.Players.LocalPlayer then i = -1 end
        scroller[v.plr.Value.Name].LayoutOrder = i
    end
    if lastinfized then info.Text = finfo:format(infize(lastinfized)) end    
end
table.insert(connections, scroller.ChildAdded:Connect(function(v)
    scroller.Size = UDim2.new(1,0,0,20*(#scroller:GetChildren()-1))
    back.Position = UDim2.new(0,200,1,-20-20*(#scroller:GetChildren()-1))
    update()
end))
table.insert(connections, scroller.ChildRemoved:Connect(function(v)
    scroller.Size = UDim2.new(1,0,0,20*(#scroller:GetChildren()-1))
    back.Position = UDim2.new(0,200,1,-20-20*(#scroller:GetChildren()-1))
    update()
end))



local playerframe = Instance.new("TextButton")
playerframe.Text = ''
playerframe.Size = UDim2.new(1,0,0,20)
playerframe.BackgroundColor3 = defcol
local plrav = Instance.new("ImageLabel", playerframe)
plrav.Size = UDim2.new(0,20,0,20)
plrav.BackgroundTransparency = 1
plrav.Name = 'Image'
local pname = Instance.new("TextLabel", playerframe)
pname.Text = "Hello, World!"
pname.Size = UDim2.new(0,130,0,20)
pname.Position = UDim2.fromOffset(20,0)
pname.BackgroundTransparency = 1
pname.TextColor3 = white
pname.TextScaled = true
pname.Name = 'Disp'
pname.RichText = true
local pblox = pname:Clone()
pblox.Name = 'Blox'
pblox.TextScaled = false
pblox.TextSize = 10
pblox.Size = UDim2.new(0,50,0,20)
pblox.Position = UDim2.new(1,-50,0,0)
pblox.Text = '+99,999'
pblox.Parent = playerframe



local function make(plr, startup)
    local name = plr.Name
    local path = ds:WaitForChild(name, 60)
    assert(path, 'Unable to find data store for '..name)
    local newentry = newproxy(true)
    getmetatable(newentry).__index = function(self, index)
        if index == 'plr' then 
            return {Value = plr}
        elseif index == 'path' then
            return {value = path}
        elseif matchtbl[index] and path:FindFirstChild(matchtbl[index]) then
            return path[matchtbl[index]] 
        end
    end
    table.insert(players, newentry)
    local new = playerframe:Clone()
    task.spawn(function() new.Image.Image = plricon(plr.UserId) end)
    new.Name = name
    new.Disp.Text = fname:format(plr.DisplayName)
    new.Blox.Text = fblox:format("-")
    new.Parent = scroller
    new.MouseButton1Click:Connect(function()
        if lastinfized == newentry then info.Visible = not info.Visible else info.Visible = true end
        info.Text = finfo:format(infize(newentry))
    end)
    if not startup then print('added '..plr.Name) end
    return newentry
end
for i,v in pairs(game.Players:GetPlayers()) do make(v, true) end
table.insert(connections, game.Players.PlayerAdded:Connect(make))
local function remove(plr)
    print('removing '..plr.Name)
    local auto
    for i,v in pairs(players) do
        if v.plr.Value == plr then 
            table.remove(players, i)
            if scroller:FindFirstChild(plr.Name) then auto = true scroller[plr.Name]:Destroy() end
        break end
    end
    if not auto then update() end
end
table.insert(connections, game.Players.PlayerRemoving:Connect(remove))
local bloxdata = {}
for i,v in pairs(players) do
    local mode = v[(rs.Info.Gamemode.Value == 'Normal' and 'sblox') or 'hblox']
    local ui = scroller:FindFirstChild(v.plr.Value.Name)
    if not (mode and ui) then continue end
    bloxdata[v] = mode.Value
    ui.Blox.Text = fblox:format("-")
end
table.insert(connections, game.Players.LocalPlayer.PlayerGui.ChildAdded:Connect(function(c)
    if c.Name == 'SurvivedGui' or c.Name == 'WipeoutGui' then
        title.Text = '<font color="#FF66B2"><b>Syncing with server...</b></font>'
        task.wait(2.5)
        title.Text = '<font color="#00994C"><b>Calculating...</b></font>'
        task.wait(0.5)
        title.Text = '<font color="#9999FF"><b>blox watch</b></font>'
        for i,v in pairs(players) do
            local mode = (rs.Info.Gamemode.Value == 'Normal' and 'sblox') or 'hblox'
            --print(mode, v[mode].Value, bloxdata[v])
            local diff, ui = math.clamp((v[mode] and v[mode].Value or 0) - (bloxdata[v] or (v[mode] and v[mode].Value or 0)),0,math.huge), scroller:FindFirstChild(v.plr.Value.Name)
            if not (diff and ui) then continue end
            ui.Blox.Text = fblox:format("+"..cv(diff*2))
        end
        bloxdata = {}
        update()
    elseif c.Name == 'DisasterGui' or c.Name == 'MultiDisasterGui' then
        title.Text = '<font color="#4C73AC"><b>Waiting for server...</b></font>'
        for i,v in pairs(players) do
            local mode = v[(rs.Info.Gamemode.Value == 'Normal' and 'sblox') or 'hblox']
            local ui = scroller:FindFirstChild(v.plr.Value.Name)
            if not (mode and ui) then continue end
            bloxdata[v] = mode.Value
            ui.Blox.Text = fblox:format("-")
        end
        update()
    else print(c) end
end))
table.insert(connections, game:GetService("UserInputService").InputBegan:Connect(function(key, chat)
    if not chat and key.KeyCode == Enum.KeyCode.F3 then back.Visible = not back.Visible end
end))